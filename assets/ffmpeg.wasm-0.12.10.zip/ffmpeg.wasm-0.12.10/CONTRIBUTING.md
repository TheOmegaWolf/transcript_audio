Check https://ffmpegwasm.netlify.app/docs/contribution/core
