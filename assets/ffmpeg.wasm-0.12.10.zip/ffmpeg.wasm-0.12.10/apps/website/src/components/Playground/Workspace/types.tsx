export interface Node {
  name: string;
  isDir: boolean;
}
