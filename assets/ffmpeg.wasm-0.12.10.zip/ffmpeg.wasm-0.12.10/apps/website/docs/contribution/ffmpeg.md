# @ffmpeg/ffmpeg

The source code of @ffmpeg/ffmpeg locates at **/packages/ffmpeg**.

## Development

```bash
$ npm run dev
```

## Build

Transpile Typescript to JavaScript.

```bash
$ npm run build
```

## Lint

```bash
$ npm run lint
```

## Publish

Simply run `npm publish` under **packages/ffmpeg**.
