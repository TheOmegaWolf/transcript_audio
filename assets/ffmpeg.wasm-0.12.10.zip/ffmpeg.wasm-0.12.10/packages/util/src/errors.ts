export const ERROR_RESPONSE_BODY_READER = new Error(
  "failed to get response body reader"
);
export const ERROR_INCOMPLETED_DOWNLOAD = new Error(
  "failed to complete download"
);
